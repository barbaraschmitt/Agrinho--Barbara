function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
// Variáveis globais do jogo
let estado = 'inicio'; // Estados: 'inicio', 'jogando', 'fim'
let score = 0;
const scoreMax = 10; // Pontuação para vencer

let cestaX; // Posição X da cesta
const cestaY = 430; // Posição Y para a base da cesta

let macasBoas = [];
let macasRuins = [];

// Array para armazenar as características das TRÊS árvores de fundo (macieiras)
let arvoresDeFundo = [];
const numArvoresFundo = 3; // Apenas 3 macieiras no fundo

// REMOVI COMPLETAMENTE QUALQUER RASTRO DE MILHO OU PINHEIROS

// --- Pré-carrega recursos (como fontes) ---
function preload() {
  // NENHUMA MUDANÇA AQUI - a fonte 'Press Start 2P' é carregada via HTML
  // (Certifique-se de que a linha de importação no seu index.html está correta)
}

function setup() {
  createCanvas(800, 500); // Tamanho do canvas

  // A cesta começa no centro horizontal da tela
  cestaX = width / 2;

  // Inicializa as maçãs pela primeira vez
  reiniciarMacas();

  // --- Inicializa as características das TRÊS macieiras de fundo uma única vez ---
  arvoresDeFundo.push({
    x: 150, // Posição da primeira macieira (esquerda)
    height: 120, // Altura total da macieira
    trunkHeight: 50, // Altura do tronco
    trunkWidth: 30 // Largura do tronco
  });
  arvoresDeFundo.push({
    x: 300, // Posição da segunda macieira (meio-esquerda)
    height: 100, // Altura total da macieira
    trunkHeight: 45, // Altura do tronco
    trunkWidth: 28 // Largura do tronco
  });
  arvoresDeFundo.push({
    x: 450, // Posição da terceira macieira (meio)
    height: 140, // Altura total da macieira
    trunkHeight: 55, // Altura do tronco
    trunkWidth: 32 // Largura do tronco
  });

  // Configurações de texto padrão
  textAlign(CENTER, CENTER); // GARANTIA DE QUE O TEXTO SERÁ CENTRALIZADO POR PADRÃO
  textFont('Press Start 2P', 40);
}

function draw() {
  if (estado === 'inicio') {
    telaInicio();
  } else if (estado === 'jogando') {
    jogar();
  } else if (estado === 'fim') {
    telaFim();
  }
}

// --- Funções de Tela ---

function telaInicio() {
  background(25, 25, 112); // Azul Marinho Profundo

  // Título do jogo
  fill(255, 215, 0); // Amarelo Ouro
  stroke(139, 69, 19); // Marrom Sela
  strokeWeight(6);
  textSize(80); // Tamanho maior para o título
  fill(200, 150, 0);
  text('COLHEITA', width / 2 + 5, height / 3 + 5);
  fill(255, 215, 0);
  text('COLHEITA', width / 2, height / 3);

  // Botão START
  fill(255, 215, 0); // Amarelo Ouro
  stroke(139, 69, 19); // Marrom Sela
  strokeWeight(4);
  rectMode(CENTER);
  rect(width / 2, height / 2 + 100, 200, 70, 20); // Botão maior e com bordas arredondadas

  fill(30, 144, 255); // Azul Celeste
  noStroke();
  textSize(40);
  text('START', width / 2, height / 2 + 100);

  // Instruções menores
  textSize(18);
  fill(255);
  text('Clique em START para começar', width / 2, height - 50);
}

function mousePressed() {
  if (estado === 'inicio') {
    if (
      mouseX > width / 2 - 100 &&
      mouseX < width / 2 + 100 &&
      mouseY > height / 2 + 65 &&
      mouseY < height / 2 + 135
    ) {
      estado = 'jogando';
      score = 0; // Reseta a pontuação
      reiniciarMacas(); // Reposiciona as maçãs para um novo jogo
    }
  } else if (estado === 'fim') {
    estado = 'inicio';
    score = 0; // Reseta a pontuação
    reiniciarMacas(); // Reposiciona as maçãs
    }
}

function jogar() {
  desenharFundo();
  moverCesta();
  desenharCestaDeFrutas(cestaX, cestaY);
  moverMacas();
  checarColisao();
  mostrarPlacar();

  // Verifica condição de vitória
  if (score >= scoreMax) {
    estado = 'fim';
  }
}

function telaFim() {
  desenharFundo();

  // Texto "VOCÊ VENCEU!" CENTRALIZADO
  fill(255, 215, 0); // Amarelo Ouro
  stroke(139, 69, 19); // Marrom Sela
  strokeWeight(6);
  textSize(60);
  // Alinhamento já foi definido como CENTER no setup, então basta usar width / 2 para o X
  // E ajustar o Y para o centro visual
  fill(200, 150, 0);
  text('VOCÊ VENCEU!', width / 2 + 5, height / 3 + 5); // Deslocamento sutil para sombra
  fill(255, 215, 0);
  text('VOCÊ VENCEU!', width / 2, height / 3);

  // Botão JOGAR NOVAMENTE
  fill(255, 215, 0); // Amarelo Ouro
  stroke(139, 69, 19); // Marrom Sela
  strokeWeight(4);
  rectMode(CENTER);
  rect(width / 2, height / 2 + 100, 300, 70, 20);

  fill(30, 144, 255); // Azul Celeste
  noStroke();
  textSize(30);
  text('JOGAR NOVAMENTE', width / 2, height / 2 + 100);

  // Mostra a pontuação final
  fill(255, 255, 255);
  noStroke();
  textSize(24);
  text(`Pontuação Final: ${score}/${scoreMax}`, width / 2, height / 2 + 170);
}

// --- Funções de Desenho ---

function desenharFundo() {
  noStroke();

  // Céu - com um gradiente sutil
  for (let i = 0; i < height / 2; i++) {
    let inter = map(i, 0, height / 2, 0, 1);
    let c = lerpColor(color(135, 206, 250), color(0, 100, 200), inter);
    stroke(c);
    line(0, i, width, i);
  }

  // Grama - com pequenas variações de cor para realismo
  for (let i = height / 2; i < height; i++) {
    let inter = map(i, height / 2, height, 0, 1);
    let c = lerpColor(color(34, 139, 34), color(0, 80, 0), inter);
    stroke(c);
    line(0, i, width, i);
  }
  noStroke();

  desenharNuvens();
  desenharMacieirasDeFundo(); // DESENHA APENAS AS MACIEIRAS
}

function desenharNuvens() {
  fill(255, 255, 255, 200); // Branco com transparência suave
  noStroke();

  // Nuvem 1 (esquerda)
  ellipse(120, 70, 70, 40);
  ellipse(160, 65, 60, 35);
  ellipse(140, 55, 65, 40);
  ellipse(100, 60, 50, 30);

  // Nuvem 2 (meio)
  ellipse(380, 40, 90, 50);
  ellipse(430, 50, 70, 40);
  ellipse(420, 35, 60, 40);
  ellipse(360, 45, 80, 45);

  // Nuvem 3 (direita)
  ellipse(650, 80, 80, 45);
  ellipse(700, 70, 60, 30);
  ellipse(680, 65, 55, 40);
  ellipse(630, 75, 70, 35);
}

// --- FUNÇÃO: Desenha as três árvores com troncos grossos e folhagens onduladas com maçãs ---
function desenharMacieirasDeFundo() {
  for (let i = 0; i < numArvoresFundo; i++) {
    let arvore = arvoresDeFundo[i];

    push();
    translate(arvore.x, height / 2 - arvore.trunkHeight); 

    // Tronco Grosso
    fill(101, 67, 33); 
    rectMode(CENTER); 
    rect(0, arvore.trunkHeight / 2, arvore.trunkWidth, arvore.trunkHeight); 

    // Folhagem Circular Ondulada
    fill(34, 139, 34); 
    noStroke();
    
    ellipse(0, 0, 80, 70); 
    ellipse(-30, 15, 60, 50); 
    ellipse(30, 15, 60, 50); 
    ellipse(-20, -20, 50, 40); 
    ellipse(20, -20, 50, 40); 

    // Adiciona Maçãs na Macieira
    fill(220, 20, 60); 
    ellipse(-15, 10, 20, 20);
    fill(34, 139, 34); 
    triangle(-15, 10 - 10, -12, 10 - 7, -18, 10 - 7);

    fill(220, 20, 60);
    ellipse(20, -5, 20, 20);
    fill(34, 139, 34);
    triangle(20, -5 - 10, 23, -5 - 7, 17, -5 - 7);
    
    fill(220, 20, 60);
    ellipse(0, 30, 20, 20);
    fill(34, 139, 34);
    triangle(0, 30 - 10, 3, 30 - 7, -3, 30 - 7);

    pop();
  }
}
// --- FIM DA FUNÇÃO DE MACIEIRAS ---


// --- FUNÇÃO: CESTA DE FRUTAS ---
function desenharCestaDeFrutas(x, y) {
  push();
  translate(x, y);

  let cestaLargura = 120;
  let cestaAlturaBase = 20;
  let cestaAlturaLateral = 60;

  fill(139, 69, 19);
  stroke(101, 67, 33);
  strokeWeight(2);
  ellipse(0, 0, cestaLargura, cestaAlturaBase);

  fill(139, 69, 19);
  arc(0, 0, cestaLargura, cestaAlturaBase * 2, 0, PI);
  
  for (let i = 0; i < 5; i++) {
    noFill();
    stroke(101, 67, 33, 150);
    strokeWeight(3);
    let currentY = -cestaAlturaLateral + (i * (cestaAlturaLateral / 5)) + cestaAlturaBase / 2;
    ellipse(0, currentY, cestaLargura - (i * 10), cestaAlturaBase + (i * 2));
  }
  
  noStroke();

  fill(220, 20, 60);
  ellipse(-30, -cestaAlturaLateral + 30, 25, 25);
  fill(34, 139, 34);
  triangle(-30, -cestaAlturaLateral + 30 - 15, -25, -cestaAlturaLateral + 30 - 10, -35, -cestaAlturaLateral + 30 - 10);

  fill(255, 140, 0);
  ellipse(0, -cestaAlturaLateral + 25, 28, 28);

  fill(50, 205, 50);
  ellipse(30, -cestaAlturaLateral + 35, 26, 26);
  fill(101, 67, 33);
  rect(30, -cestaAlturaLateral + 35 - 15, 2, 8);

  fill(128, 0, 128);
  ellipse(-10, -cestaAlturaLateral + 45, 15, 15);
  ellipse(-20, -cestaAlturaLateral + 50, 15, 15);
  ellipse(-5, -cestaAlturaLateral + 55, 15, 15);

  fill(255, 255, 0);
  arc(20, -cestaAlturaLateral + 50, 30, 15, PI/2, PI*1.5);
  rect(15, -cestaAlturaLateral + 45, 5, 20);

  noFill();
  stroke(101, 67, 33);
  strokeWeight(4);
  ellipse(0, -cestaAlturaLateral + cestaAlturaBase / 2, cestaLargura, cestaAlturaBase + 10);

  noFill();
  stroke(101, 67, 33);
  strokeWeight(6);
  arc(0, -cestaAlturaLateral - 10, cestaLargura - 20, cestaAlturaLateral + 10, PI, TWO_PI);

  pop();
}
// --- FIM DA FUNÇÃO CESTA DE FRUTAS ---


function moverCesta() {
  if (keyIsDown(LEFT_ARROW)) {
    cestaX -= 8;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    cestaX += 8;
  }
  cestaX = constrain(cestaX, 70, width - 70);
}

function moverMacas() {
  for (let m of macasBoas) {
    m.y += m.speed;
    if (m.y > height + 20) {
      m.x = random(50, width - 50);
      m.y = random(-600, -50);
      m.speed = random(2, 4);
    }
    desenharMacaBoa(m.x, m.y);
  }

  for (let m of macasRuins) {
    m.y += m.speed;
    if (m.y > height + 20) {
      m.x = random(50, width - 50);
      m.y = random(-800, -100);
      m.speed = random(3, 5);
    }
    desenharMacaRuim(m.x, m.y);
  }
}

function desenharMacaBoa(x, y) {
  push();
  translate(x, y);
  noStroke();

  fill(220, 20, 60);
  ellipse(0, 0, 35, 40);

  fill(255, 255, 255, 100);
  ellipse(-10, -10, 8, 12);

  fill(34, 139, 34);
  rotate(radians(30));
  ellipse(15, -15, 20, 10);

  stroke(101, 67, 33);
  strokeWeight(3);
  line(0, -20, 0, -8);
  pop();
}

function desenharMacaRuim(x, y) {
  push();
  translate(x, y);
  noStroke();

  fill(30, 20, 10);
  ellipse(0, 0, 35, 40);

  fill(60, 40, 20, 180);
  ellipse(-8, -5, 15, 10);
  ellipse(10, 5, 12, 8);
  ellipse(0, 10, 10, 15);

  fill(50, 40, 30);
  rotate(radians(-20));
  ellipse(10, -15, 20, 10);

  stroke(60, 50, 40);
  strokeWeight(3);
  line(0, -20, 0, -8);
  pop();
}

function checarColisao() {
  const cestaTopoY = cestaY - 70;
  const cestaLargura = 120;

  for (let i = macasBoas.length - 1; i >= 0; i--) {
    let m = macasBoas[i];
    if (
      m.x > cestaX - cestaLargura / 2 + 10 &&
      m.x < cestaX + cestaLargura / 2 - 10 &&
      m.y > cestaTopoY &&
      m.y < cestaY
    ) {
      score++;
      m.x = random(50, width - 50);
      m.y = random(-600, -50);
      m.speed = random(2, 4);
    }
  }

  for (let i = macasRuins.length - 1; i >= 0; i--) {
    let m = macasRuins[i];
    if (
      m.x > cestaX - cestaLargura / 2 + 10 &&
      m.x < cestaX + cestaLargura / 2 - 10 &&
      m.y > cestaTopoY &&
      m.y < cestaY
    ) {
      score = max(0, score - 1);
      m.x = random(50, width - 50);
      m.y = random(-800, -100);
      m.speed = random(3, 5);
    }
  }
}

function mostrarPlacar() {
  fill(255, 215, 0);
  stroke(139, 69, 19);
  strokeWeight(3);
  textSize(30);
  textAlign(LEFT, TOP);
  text(`Pontos: ${score}/${scoreMax}`, 20, 20);
}

function reiniciarMacas() {
  macasBoas = [];
  macasRuins = [];

  for (let i = 0; i < 6; i++) {
    macasBoas.push({
      x: random(50, width - 50),
      y: random(-600, -50),
      speed: random(2, 4)
    });
  }
  for (let i = 0; i < 4; i++) {
    macasRuins.push({
      x: random(50, width - 50),
      y: random(-800, -100),
      speed: random(3, 5)
    });
  }
}